// ==UserScript==
// @include https://twitter.com
// @include http://twitter.com
// ==/UserScript==

console.log('content script running');
